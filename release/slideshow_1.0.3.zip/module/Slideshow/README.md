# Slideshow
Slideshow module for Dream CMS. Module allows to publish photos slideshow on the site.

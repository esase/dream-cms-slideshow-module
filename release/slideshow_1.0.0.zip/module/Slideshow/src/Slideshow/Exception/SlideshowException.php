<?php
namespace Slideshow\Exception;
use Exception;

class SlideshowException extends Exception
{}
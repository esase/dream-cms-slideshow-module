DROP TABLE IF EXISTS `slideshow_image`;
DROP TABLE IF EXISTS `slideshow_category`;
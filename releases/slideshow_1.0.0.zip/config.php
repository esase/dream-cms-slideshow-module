<?php 

return [
	'module_path' => 'module/Slideshow',
    'layout_path' => 'layout/slideshow'
];
